#include "Scene.h"
#include"Game.h"
scene::scene() : game(game::getInstance())
{
}