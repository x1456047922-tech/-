
#pragma once
#include <SDL.h>

enum class ItemType { 
    HEALTH, 
    SHIFT,
    TIME
};

struct player
{
    public:
    SDL_Texture* texture = nullptr;
    SDL_FPoint position = {0, 0};
    int width = 0;
    int height = 0;
    int speed = 500;
    int currenthealth = 10;
    int maxhealth = 10;
    Uint32 coolDown = 300;
    Uint32 lastShootTime = 0;
};
struct projectileplayer
{
    public:
    SDL_Texture* texture = nullptr;
    SDL_FPoint position = {0, 0};
    int width = 0;
    int height = 0;
    int speed = 600;
    int damage = 1;
};
struct enemy
{
    public:
    SDL_Texture* texture = nullptr;
    SDL_FPoint position = {0, 0};
    int width = 0;
    int height = 0;
    int speed = 200;
    int health = 1;
    int damage = 1;
     Uint32 coolDown = 1000;
    Uint32 lastShootTime = 0;
};
struct projectileenemy
{
    public:
    SDL_Texture* texture = nullptr;
    SDL_FPoint position = {0, 0};
    SDL_FPoint direction = {0, 0};
    int damage = 1;
    int width = 0;
    int height = 0;
    int speed = 400;
};
struct explosion{
    public:
    SDL_Texture* texture = nullptr;
    SDL_FPoint position = {0, 0};
    int width = 0;
    int height = 0;
    int currentFrame = 0;
    int totalFrame = 0; 
    Uint32   startTime = 0;
    Uint32 FPS = 10;
};
struct Item{
    public:
    SDL_Texture* texture = nullptr;
    SDL_FPoint position = {0, 0};
    SDL_FPoint direction = {0, 0};
    int width = 0;
    int height = 0;
    int speed = 100;
    int bounce = 3;
    ItemType type = ItemType::HEALTH;
};
struct background{
    SDL_Texture* texture = nullptr;
    SDL_FPoint position = {0, 0};
    int width = 0;
    int height = 0;
    int speed = 30;
    float offset = 0;
};