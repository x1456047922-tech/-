#pragma once
#include "Scene.h"
#include "Object.h"
#include <list>
#include <random>
#include <SDL_mixer.h>
#include <SDL_image.h>
#include <map>
#include <SDL_ttf.h>

class game;
 class Scenemain : public scene{
 public:
    ~Scenemain();

   void update(float deltaTime) override;
   void render() override;
   void handleEvents(SDL_Event *event) override;
   void init() override;
   void clean() override;
   
private:
std::mt19937 gen;
std::uniform_real_distribution<float> dis;
   
   int score=0;//分数
   player  Player;
   projectileplayer ProjectileplayerTemplate;
   bool isDead=false;//游戏是否结束
   std::list<projectileplayer*> projectilesPlayer;
   enemy EnemyTemplate;
   Item ItemhealthTemplate;
   //敌机容器
   std::list<enemy*> enemies;
   std::list<projectileenemy*> enemyProjectiles;//敌机子弹容器
   projectileenemy enemyProjectileTemplate;
   explosion ExplosionTemplate;
   std::list<explosion*> explosions;//爆炸容器
   std::list<Item*> items;//道具容器
   Mix_Music* bgm ; //背景音乐
   std::map<std::string, Mix_Chunk*> soundEffects; //音效容器
   SDL_Texture *uihealth;
   TTF_Font* scorefont;

   void keyboardcontrol(float deltaTime) ;
   void shootplayer();
   void updateplayerprojectiles(float deltaTime);
   void renderplayerprojectiles();
   void spawnenemy();
   void updateenemies(float deltaTime);
   void renderenemies();
   void renderenemyprojectiles();
   void shootenemy(enemy* enemyShooter);
   SDL_FPoint getDirection(enemy* enemyShooter);
   void updateenemyprojectiles(float deltaTime);
   void enemyexplode(enemy* enemy);//敌机爆炸
   void updateplayer(float deltaTime);
   void updateExplosions(float deltaTime);
   void renderExplosions();
   void dropitem(enemy* enemy);
   void updateItems(float deltaTime);
   void playgetitem(Item* item);//游戏结束
   void renderItems();
   void renderUI();
 };
 
