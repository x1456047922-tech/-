#include "Game.h"
#include "SceneMain.h"
#include "SceneTitle.h"
game::game()    
{
}
game::~game()
{
    clean();
}
void game::init()
{   
    frameTime = 1000 / FPS;//每帧的时间
    if(SDL_Init(SDL_INIT_EVERYTHING) != 0){
        isRunning = false;
        SDL_LogError(SDL_LOG_CATEGORY_ERROR ,"SDL_Init Error: %s\n", SDL_GetError());   
    }
    window = SDL_CreateWindow("SDL Shooter", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, windowWidth, windowHeight, SDL_WINDOW_SHOWN);
    if (window == nullptr){
        isRunning = false;
        SDL_LogError(SDL_LOG_CATEGORY_ERROR ,"SDL_CreateWindow Error: %s\n", SDL_GetError());   
    }
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);    
    if (renderer == nullptr){
        isRunning = false;
        SDL_LogError(SDL_LOG_CATEGORY_ERROR ,"SDL_CreateRenderer Error: %s\n", SDL_GetError());   
    }
     if (IMG_Init(IMG_INIT_PNG) != IMG_INIT_PNG) {
        SDL_LogError(SDL_LOG_CATEGORY_ERROR, "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
        isRunning = false;
    }
    if (Mix_Init(MIX_INIT_MP3 | MIX_INIT_OGG) != (MIX_INIT_MP3 | MIX_INIT_OGG)) {
        SDL_LogError(SDL_LOG_CATEGORY_ERROR, "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError());
        isRunning = false;
    }
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        SDL_LogError(SDL_LOG_CATEGORY_ERROR, "SDL_mixer could not open audio! SDL_mixer Error: %s\n", Mix_GetError());
        isRunning = false;
    }
    nearstars.texture = IMG_LoadTexture(renderer, "assets/image/Stars-A.png");
    SDL_QueryTexture(nearstars.texture, NULL, NULL, &nearstars.width, &nearstars.height);
    nearstars.height /= 2;
    nearstars.width /= 2;
    farstars.texture = IMG_LoadTexture(renderer, "assets/image/Stars-B.png");
    SDL_QueryTexture(farstars.texture, NULL, NULL, &farstars.width, &farstars.height);
    farstars.height /= 2;
    farstars.width /= 2;
    farstars.speed = 20;
    //设置音效通道
    Mix_AllocateChannels(32);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 4); //设置最大音量
    Mix_Volume(-1, MIX_MAX_VOLUME / 8); //设置所有音效的最大音量
    if(TTF_Init() == -1){
        SDL_LogError(SDL_LOG_CATEGORY_ERROR, "SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
        isRunning = false;
    }

    title = TTF_OpenFont("assets/font/VonwaonBitmap-16px.ttf", 64);
    textfont = TTF_OpenFont("assets/font/VonwaonBitmap-16px.ttf", 32);
    if (title == nullptr||textfont == nullptr) {
        SDL_LogError(SDL_LOG_CATEGORY_ERROR, "SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
        isRunning = false;
    }
    currentScene = new SceneTitle();
    currentScene->init();
    
}
void game::run(){
    while(isRunning){
        auto frameStart = SDL_GetTicks();
        SDL_Event event;
        handleEvents(&event);
        update(deltaTime); 
        render();
        auto frameEnd = SDL_GetTicks();
        auto Diff = frameEnd - frameStart;
        if(Diff < frameTime){
            SDL_Delay(frameTime - Diff);
            deltaTime = frameTime / 1000.0f;
        }
        else{
            deltaTime = Diff / 1000.0f;
        }
    }
}
void game::changeScene(scene* Scene){
    if (currentScene != nullptr) {
        currentScene->clean();
        delete currentScene;
    } 
    currentScene = Scene;
    currentScene->init();
}
void game::clean(){
        if (currentScene != nullptr) {
            currentScene->clean();
            delete currentScene;
        }
        if(nearstars.texture != nullptr){
            SDL_DestroyTexture(nearstars.texture);
        }
        if(farstars.texture != nullptr){
            SDL_DestroyTexture(farstars.texture);
        }
        SDL_CloseAudio();
        Mix_Quit();
        SDL_RenderClear(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        TTF_Quit();
    }
void game::handleEvents(SDL_Event* event){
     while(SDL_PollEvent(event)){
            if(event->type == SDL_QUIT){
                isRunning = false;
            }
            currentScene->handleEvents(event);
}
}
void game::update( float deltaTime){
    backgroundupadte(deltaTime);
    currentScene->update(deltaTime);
}
void game::render()
{      
        //清空
        SDL_RenderClear(renderer);
         backgroundrender();
        //渲染
        currentScene->render();
        //呈现
        SDL_RenderPresent(renderer);

}

void game::rendertextcenter(std::string text, float posy, bool istitle)
{

    SDL_Color color = {255, 255, 255, 255};
    SDL_Surface* surface;
    if (istitle) {
         surface = TTF_RenderText_Solid(title, text.c_str(), color);
    }
    else {
         surface = TTF_RenderText_Solid(textfont, text.c_str(), color);
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    int y = static_cast<int>((windowHeight / 2 - surface->h)*posy);
    SDL_Rect dst = {getWindowWidth()/2 - surface->w / 2  , y ,surface->w,surface->h}; 
    SDL_RenderCopy(renderer, texture, NULL, &dst);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);

}

void game::backgroundupadte(float deltaTime)
{
    nearstars.offset += nearstars.speed * deltaTime;
    if (nearstars.offset >= 0) {
        nearstars.offset -= nearstars.height;
    }
    farstars.offset += farstars.speed * deltaTime;
    if (farstars.offset >= 0) {
        farstars.offset -= farstars.height;
    }
}

void game::backgroundrender()
{
    for(int PosY=static_cast<int>(farstars.offset); PosY < windowHeight; PosY += farstars.height)
    {
        for(int PosX=0; PosX < windowWidth; PosX += farstars.width)
        {
            SDL_Rect dst = {PosX, PosY, farstars.width, farstars.height};
            SDL_RenderCopy(renderer, farstars.texture, NULL, &dst);
        }
    }

    for(int PosY=static_cast<int>(nearstars.offset); PosY < windowHeight; PosY += nearstars.height)
    {
        for(int PosX=0; PosX < windowWidth; PosX += nearstars.width)
        {
            SDL_Rect dst = {PosX, PosY, nearstars.width, nearstars.height};
            SDL_RenderCopy(renderer, nearstars.texture, NULL, &dst);
        }
        
    }
}
