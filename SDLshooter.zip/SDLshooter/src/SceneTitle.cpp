#include"SceneTitle.h"
#include "SceneMain.h"
#include "Game.h"
#include <string>

void SceneTitle::update(float deltaTime)
{
    timer += deltaTime;
    if (timer > 1.0f){
        timer -= 1.0f;
    }
}

void SceneTitle::render()
{
    //渲染标题文字
    std::string title = "SAVE ROC";
    game.rendertextcenter(title, 0.4, true);
    //渲染开始文字
     if (timer < 0.5f){
        std::string instructions = "press J to destory the CCP";
        game.rendertextcenter(instructions, 0.8, false);
    }
}

void SceneTitle::handleEvents(SDL_Event *event)
{
    if (event->type == SDL_KEYDOWN)
    {
        if(event->key.keysym.scancode == SDL_SCANCODE_J)
        {
            auto main_scene=new Scenemain();
            game.changeScene(main_scene);
        }
    }
    
}

void SceneTitle::init()
{
    bgm= Mix_LoadMUS("assets/music/06_Battle_in_Space_Intro.ogg");
    if(bgm == nullptr){
        SDL_Log("Failed to load music! SDL_mixer Error: %s\n", Mix_GetError());
    }
    Mix_PlayMusic(bgm, -1);
}

void SceneTitle::clean()
{
       if (bgm != nullptr) {
        Mix_HaltMusic();
        Mix_FreeMusic(bgm);
       }
}
