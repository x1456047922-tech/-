#include "SceneMain.h"
#include "Game.h"
#include <SDL.h>
#include <random>
#include <string>
#include "SceneTitle.h"
Scenemain::~Scenemain() 
{
    

}
void Scenemain::init() //init the player
{

    //初始化音乐
   
    bgm = Mix_LoadMUS("assets/music/03_Racing_Through_Asteroids_Loop.ogg");
    if (bgm == nullptr) {
        SDL_LogError(SDL_LOG_CATEGORY_ERROR, "Failed to load background music: %s", Mix_GetError());
    } else {
        Mix_PlayMusic(bgm, -1); // 循环播放背景音乐
    }

    soundEffects["player_shoot"] = Mix_LoadWAV("assets/sound/laser_shoot4.wav");
    soundEffects["enemy_shoot"] = Mix_LoadWAV("assets/sound/xs_laser.wav");
    soundEffects["player_explode"] = Mix_LoadWAV("assets/sound/explosion1.wav");
    soundEffects["enemy_explode"] = Mix_LoadWAV("assets/sound/explosion3.wav");
    soundEffects["hit"] = Mix_LoadWAV("assets/sound/eff11.wav");
    soundEffects["item"] = Mix_LoadWAV("assets/sound/eff5.wav");


    std:: random_device rd;
    gen= std:: mt19937 (rd());
    dis=std:: uniform_real_distribution<float>(0.0f,1.0f);
    auto r = dis(gen);

    Player.texture = IMG_LoadTexture(game.getRenderer(),"assets/image/SpaceShip.png");
        if (Player.texture == nullptr) {
            SDL_LogError(SDL_LOG_CATEGORY_ERROR, "Failed to load player texture:%s", SDL_GetError());
        }
    SDL_QueryTexture(Player.texture, NULL, NULL, &Player.width, &Player.height);
    Player.width /= 4;
    Player.height /= 4;
    Player.position.x = game.getWindowWidth() / 2 - Player.width / 2;
    Player.position.y = game.getWindowHeight() - Player.height;
//初始化模板
    ProjectileplayerTemplate.texture = IMG_LoadTexture(game.getRenderer(),"assets/image/laser-1.png");
    SDL_QueryTexture(ProjectileplayerTemplate.texture, NULL, NULL, &ProjectileplayerTemplate.width, &ProjectileplayerTemplate.height);
    ProjectileplayerTemplate.width /= 4;
    ProjectileplayerTemplate.height /= 4;

    //初始化敌人模板
    EnemyTemplate.texture = IMG_LoadTexture(game.getRenderer(),"assets/image/insect-1.png");
    SDL_QueryTexture(EnemyTemplate.texture, NULL, NULL, &EnemyTemplate.width, &EnemyTemplate.height);
    EnemyTemplate.width /= 4;
    EnemyTemplate.height /= 4;

    enemyProjectileTemplate.texture = IMG_LoadTexture(game.getRenderer(),"assets/image/laser-2.png");
    SDL_QueryTexture(enemyProjectileTemplate.texture, NULL, NULL, &enemyProjectileTemplate.width, &enemyProjectileTemplate.height);
    enemyProjectileTemplate.width /= 4;
    enemyProjectileTemplate.height /= 4;

    ExplosionTemplate.texture = IMG_LoadTexture(game.getRenderer(),"assets/effect/explosion.png");
    SDL_QueryTexture(ExplosionTemplate.texture, NULL, NULL, &ExplosionTemplate.width, &ExplosionTemplate.height);
    ExplosionTemplate.totalFrame = ExplosionTemplate.width / ExplosionTemplate.height;
    ExplosionTemplate.width = ExplosionTemplate.height ;

    ItemhealthTemplate.texture = IMG_LoadTexture(game.getRenderer(),"assets/image/bonus_life.png");
    SDL_QueryTexture(ItemhealthTemplate.texture, NULL, NULL, &ItemhealthTemplate.width,
                      &ItemhealthTemplate.height);
    ItemhealthTemplate.width /= 4;
    ItemhealthTemplate.height /= 4;
    uihealth = IMG_LoadTexture(game.getRenderer(),"assets/image/Health UI Black.png");
    
    scorefont = TTF_OpenFont("assets/font/VonwaonBitmap-12px.ttf", 24);

    
}
void Scenemain::update(float deltaTime) 
{
    keyboardcontrol(deltaTime);
    updateplayerprojectiles(deltaTime);
    updateenemyprojectiles(deltaTime);
    spawnenemy();
    updateenemies(deltaTime);
    updateplayer(deltaTime);
    updateExplosions(deltaTime);
    updateItems(deltaTime);
}
void Scenemain::render()

{
     
   renderenemyprojectiles();
   renderplayerprojectiles();
    if(!isDead){
         SDL_Rect playerRect = {static_cast<int>(Player.position.x), 
        static_cast<int>(Player.position.y), Player.width, Player.height};
    SDL_RenderCopy(game.getRenderer(), Player.texture, NULL, &playerRect);
    }
    renderItems();
   renderenemies();
   renderExplosions();
   renderUI();
  
}
void Scenemain::handleEvents(SDL_Event *event) 
{
      if (event->type == SDL_KEYDOWN)
    {
        if(event->key.keysym.scancode == SDL_SCANCODE_ESCAPE)
        {
            auto scenetitle=new SceneTitle();
            game.changeScene(scenetitle);

    }
}
}
void Scenemain::clean()
{
    for(auto & soundEffect : soundEffects){
        if(soundEffect.second != nullptr){
            Mix_FreeChunk(soundEffect.second);
        }
    }
    soundEffects.clear();
    // 清理玩家和子弹
      for (auto &projectile : projectilesPlayer){
        if (projectile != nullptr){
            delete projectile;
        }
    }
    projectilesPlayer.clear();
         for (auto &enemyPtr : enemies){
        if (enemyPtr != nullptr){
            delete enemyPtr;
        }
    }

    enemies.clear();
    projectilesPlayer.clear();
    
    // 清理纹理
    if (Player.texture != nullptr)
    {
        SDL_DestroyTexture(Player.texture);
    }
    if (ProjectileplayerTemplate.texture != nullptr)
    {
        SDL_DestroyTexture(ProjectileplayerTemplate.texture);
    }
   if( EnemyTemplate.texture != nullptr){
    if (EnemyTemplate.texture != nullptr)
    {
        SDL_DestroyTexture(EnemyTemplate.texture);
    }
    
    if (enemyProjectileTemplate.texture != nullptr)
    {
        SDL_DestroyTexture(enemyProjectileTemplate.texture);
    }
    for (auto &projectile : enemyProjectiles)
    {
        if (projectile != nullptr)
        {
            delete projectile;
        }
    }
    enemyProjectiles.clear();
}
  for (auto &explosion : explosions){
        if (explosion != nullptr){
            delete explosion;
        }
    }
    explosions.clear();

    for (auto &item : items){
        if (item != nullptr){
            delete item;
        }
    }
    items.clear();
    if (ExplosionTemplate.texture != nullptr){
        SDL_DestroyTexture(ExplosionTemplate.texture);
    }
    if (ItemhealthTemplate.texture != nullptr){
        SDL_DestroyTexture(ItemhealthTemplate.texture);
    }
    if (bgm != nullptr){
        Mix_HaltMusic();
        Mix_FreeMusic(bgm);
    }
    if(uihealth != nullptr){
        SDL_DestroyTexture(uihealth);
    }
    if(scorefont != nullptr){
        TTF_CloseFont(scorefont);
    }
    
}
void Scenemain::keyboardcontrol(float deltaTime)
{
    if(isDead){
        return;
    }
    auto keyboardState = SDL_GetKeyboardState(NULL);
    if (keyboardState[SDL_SCANCODE_W]) {
        Player.position.y -= deltaTime * Player.speed;
    }
    if (keyboardState[SDL_SCANCODE_S]) {
        Player.position.y += deltaTime * Player.speed;
    }
    if (keyboardState[SDL_SCANCODE_A]) {
        Player.position.x -= deltaTime * Player.speed;
    }
    if (keyboardState[SDL_SCANCODE_D]) {
        Player.position.x += deltaTime * Player.speed;
    }
    if (Player.position.x < 0) {
        Player.position.x = 0;
    }
    if(Player.position.x > game.getWindowWidth() - Player.width) {
        Player.position.x = game.getWindowWidth() - Player.width;
    }
    if (Player.position.y < 0) {
        Player.position.y = 0;
    }
    if(Player.position.y > game.getWindowHeight() - Player.height) {
        Player.position.y = game.getWindowHeight() - Player.height;
    }

    //control shooting with J key
    if (keyboardState[SDL_SCANCODE_J]) {
        Uint32 currentTime = SDL_GetTicks();
        if (currentTime - Player.lastShootTime > Player.coolDown) {
            shootplayer();
            // Shoot a projectile
            Player.lastShootTime = currentTime;
        }
    }

}
void Scenemain::renderplayerprojectiles()
{
    for ( auto& projectile : projectilesPlayer) {
        SDL_Rect projRect = {

            static_cast<int>(projectile->position.x),
            static_cast<int>(projectile->position.y),
            projectile->width,
            projectile->height
        };
        SDL_RenderCopy(game.getRenderer(), projectile->texture, NULL, &projRect);
    }
}

void Scenemain::spawnenemy()
{
    if(dis(gen)> 1/60.f)
    {
        return;
    }
    enemy * newEnemy = new enemy(EnemyTemplate);
    newEnemy->position.x = dis(gen) * (game.getWindowWidth() - newEnemy->width);
    newEnemy->position.y = 0;
    enemies.push_back(newEnemy);
}

void Scenemain::updateenemies(float deltaTime)
{
    auto currentTime = SDL_GetTicks();
    for(auto it = enemies.begin(); it != enemies.end(); )
    {
        auto enemyPtr = *it;
        enemyPtr->position.y += enemyPtr->speed * deltaTime;
        if(enemyPtr->position.y > game.getWindowHeight())
        {
            delete enemyPtr;
            it = enemies.erase(it);
        }
        else
        {
            if(currentTime - enemyPtr->lastShootTime > enemyPtr->coolDown&&!isDead){
                shootenemy(enemyPtr);
                enemyPtr->lastShootTime = currentTime;
            }
             if(enemyPtr->health <= 0)
        {
            enemyexplode(enemyPtr);
            Mix_PlayChannel(-1, soundEffects["enemy_explode"], 0); // 播放敌机爆炸音效
            it = enemies.erase(it);
        }  
            else
            {
                ++it;
            }
            
        }
    }
}

void Scenemain::renderenemies()
{
    for (auto &enemy : enemies)
    {
        SDL_Rect enemyRect = {static_cast<int>(enemy->position.x),
            static_cast<int>(enemy->position.y),
            enemy->width,
            enemy->height};
            
        SDL_RenderCopy(game.getRenderer(), enemy->texture, NULL, &enemyRect);
    } 
}

void Scenemain::renderenemyprojectiles()
{
    for (auto &projectile : enemyProjectiles) {
        SDL_Rect projRect = {
            static_cast<int>(projectile->position.x),
            static_cast<int>(projectile->position.y),
            projectile->width,
            projectile->height
        };
        float angle=atan2(projectile->position.y - Player.position.y,projectile->position.x - Player.position.x)*180.0f/3.14159f+90.0f-90;
        SDL_RenderCopyEx(game.getRenderer(), projectile->texture, NULL, &projRect, angle, NULL, SDL_FLIP_NONE);
    }
}

void Scenemain::shootenemy(enemy * enemyShooter)
{
    auto projectile = new projectileenemy(enemyProjectileTemplate);  
    // 定位在敌机底部中央
    projectile->position.x = enemyShooter->position.x + enemyShooter->width / 2 - projectile->width / 2;
    projectile->position.y = enemyShooter->position.y + enemyShooter->height;
    projectile->direction = getDirection(enemyShooter); // 设置子弹速度和方向
    // 添加到活动子弹列表
    enemyProjectiles.push_back(projectile);
    Mix_PlayChannel(1, soundEffects["enemy_shoot"], 0); // 播放射击音效
}

SDL_FPoint Scenemain::getDirection(enemy * enemyShooter)
{
    
    float deltaX = Player.position.x + Player.width / 2 - (enemyShooter->position.x + enemyShooter->width / 2);
    float deltaY = Player.position.y + Player.height / 2 - (enemyShooter->position.y + enemyShooter->height / 2);
    float distance = sqrt(deltaX * deltaX + deltaY * deltaY);
    deltaX /= distance;
    deltaY /= distance;
    return SDL_FPoint{deltaX , deltaY };
    
}

void Scenemain::updateenemyprojectiles(float deltaTime)
{
    
    for (auto it = enemyProjectiles.begin(); it != enemyProjectiles.end();)
    {
        auto margin = 32; // 子弹超出屏幕外边界的距离
        auto projectile = *it;
        // 更新子弹位置
        projectile->position.y += projectile->speed * projectile->direction.y * deltaTime
        ;        projectile->position.x += projectile->speed * projectile->direction.x * deltaTime;
        // 检查子弹是否超出屏幕
        if (projectile->position.y > game.getWindowHeight()+ margin||
            projectile->position.x < -margin ||
            projectile->position.x > game.getWindowWidth() + margin||
            projectile->position.y < -margin)
        {
            delete projectile;
            it = enemyProjectiles.erase(it);
        }
        else
        {
            SDL_Rect projectileRect = {
                static_cast<int>(projectile->position.x),
                static_cast<int>(projectile->position.y),
                projectile->width,
                projectile->height
            };
            SDL_Rect playerRect = {
                static_cast<int>(Player.position.x),
                static_cast<int>(Player.position.y),
                Player.width,
                Player.height
            };
            if (SDL_HasIntersection(&projectileRect, &playerRect)&&!isDead) {
                // 碰撞检测成功，处理碰撞
                Player.currenthealth -= projectile->damage; // TODO: 处理玩家受到伤害的逻辑
                Mix_PlayChannel(-1, soundEffects["hit"], 0); // 播放命中音效
                delete projectile;
                it = enemyProjectiles.erase(it); 
            }
            else {
                ++it;
            }
        }
    }
}

void Scenemain::enemyexplode(enemy *enemy)
{
    auto currentTime = SDL_GetTicks();
    auto Explosions = new explosion(ExplosionTemplate);
    Explosions->position.x = enemy->position.x + enemy->width / 2 - Explosions->width / 2;
    Explosions->position.y = enemy->position.y + enemy->height / 2 - Explosions->height / 2;
    Explosions->startTime = currentTime;
    explosions.push_back(Explosions);
    score += 10;
    if (dis(gen) < 0.3f){
    dropitem(enemy);
}
    delete enemy;
}

void Scenemain::updateplayer(float deltaTime)
{
    if (isDead){
        return;
    }
    if(Player.currenthealth <= 0)
    {
        auto currentTime = SDL_GetTicks();
        isDead = true; // TODO: 处理玩家死亡逻辑
        auto Explosions = new explosion(ExplosionTemplate);
        Explosions->position.x = Player.position.x + Player.width / 2 - Explosions->width / 2;
        Explosions->position.y = Player.position.y + Player.height / 2 - Explosions->height / 2;
        Explosions->startTime = currentTime;
        explosions.push_back(Explosions);
        Mix_PlayChannel(-1, soundEffects["player_explode"], 0); // 播放玩家爆炸音效
    }
    //和视频不一样，没用继承
    for (auto it = enemies.begin(); it != enemies.end(); )
    {
        SDL_Rect enemyRect = {
            static_cast<int>((*it)->position.x),
            static_cast<int>((*it)->position.y),
            (*it)->width,
            (*it)->height
        };
        SDL_Rect playerRect = {
            static_cast<int>(Player.position.x),
            static_cast<int>(Player.position.y),
            Player.width,
            Player.height
        };
        if (SDL_HasIntersection(&enemyRect, &playerRect)) {
            // 碰撞检测成功，处理碰撞
            Player.currenthealth -= (*it)->damage; // TODO: 处理玩家受到伤害的逻辑
            enemyexplode(*it);
            it = enemies.erase(it);
        }
        else
        {
            ++it;
        }
    }
}
void Scenemain::updateExplosions(float )
{
    for(auto it = explosions.begin();it != explosions.end();)
    {
        auto currentTime = SDL_GetTicks();
        auto explosion = *it;//获取当前爆炸对象
        explosion->currentFrame = (currentTime - explosion->startTime) / (1000 / explosion->FPS);

        if (explosion->currentFrame >= explosion->totalFrame)
        {
            
            // 爆炸动画结束，移除爆炸对象
            delete explosion;
            it = explosions.erase(it);
        }
        else
        {
            ++it;
        }
    }
}
void Scenemain::renderExplosions()
{
    for(auto explosion : explosions)
    {
        SDL_Rect src = {
            explosion->currentFrame * explosion->width,
            0,
            explosion->width,
            explosion->height
        };
        SDL_Rect dst = {
            static_cast<int>(explosion->position.x),
            static_cast<int>(explosion->position.y),
            explosion->width,
            explosion->height
        
        };
        SDL_RenderCopy(game.getRenderer(), explosion->texture, &src, &dst);
    }
}
void Scenemain::dropitem(enemy *enemy)
{
    auto item = new Item(ItemhealthTemplate);
    item->position.x = enemy->position.x + enemy->width / 2 - item->width / 2;
    item->position.y = enemy->position.y + enemy->height / 2 - item->height / 2;
    float angle = dis(gen) * 2.0f * 3.14159f; // 随机角度
    item->direction.x = cos(angle);
    item->direction.y = sin(angle);
    items.push_back(item);
}
void Scenemain::updateItems(float deltaTime)
{
    for (auto it = items.begin(); it != items.end();)
    {
        auto item = *it;

        // 更新物品位置
        item->position.x += item->direction.x * item->speed * deltaTime;
        item->position.y += item->direction.y * item->speed * deltaTime;
        //边缘碰撞反弹
        if (item->position.x < 0 && item->bounce>0)
        {
            item->direction.x = -item->direction.x;
            item->bounce--;
        }
        if (item->position.y < 0 && item->bounce>0)
        {
            item->direction.y = -item->direction.y;
            item->bounce--;
        }
        if (item->position.x + item->width > game.getWindowWidth() && item->bounce>0)
        {
            item->direction.x = -item->direction.x;
            item->bounce--;
        }
        if (item->position.y + item->height > game.getWindowHeight() && item->bounce>0)
        {
            item->direction.y = -item->direction.y;
            item->bounce--;
        }
            
        
        if (item->position.y + item->height < 0 || item->position.y > game.getWindowHeight() ||
            item->position.x + item->width < 0 || item->position.x > game.getWindowWidth())
        {
            delete item;
            it = items.erase(it);
        }
        else  
        {
             SDL_Rect itemRect = {
                static_cast<int>(item->position.x),
                static_cast<int>(item->position.y),
                item->width,
                item->height
             };
            SDL_Rect playerRect = {
                    static_cast<int>(Player.position.x),
                    static_cast<int>(Player.position.y),
                    Player.width,
                    Player.height
                };
            if(SDL_HasIntersection(&itemRect, &playerRect))
            {
                Mix_PlayChannel(0, soundEffects["item"], 0); // 播放获得物品音效
                 
               playgetitem(item);
               delete item;
            it = items.erase(it); // 删除当前物品
            }
            else
            {
                ++it;
            }
        }
    }
}
void Scenemain::playgetitem(Item *item)
{
    score += 5;
   if(item->type == ItemType::HEALTH)
   {
       Player.currenthealth += 1;
       if (Player.currenthealth > Player.maxhealth)
       {
           Player.currenthealth = Player.maxhealth;
       }
       
   }
}
void Scenemain::renderItems()
{
    for(auto item : items)
    {
        SDL_Rect dst = {
            static_cast<int>(item->position.x),
            static_cast<int>(item->position.y),
            item->width,
            item->height
        };
        SDL_RenderCopy(game.getRenderer(), item->texture, NULL, &dst);
    }
}
void Scenemain::renderUI()
{
    int x = 10;
    int y = 10;
    int offset = 20;
    int size = 32;
    SDL_SetTextureColorMod(uihealth, 100, 0, 0); // 红色
    for(int i = 0; i < Player.currenthealth; ++i)
    {
        SDL_Rect dst = {x + i * offset, y, size, size};
        SDL_RenderCopy(game.getRenderer(), uihealth, NULL, &dst);
        x += offset;
    }
    // Render score
    auto scoreText = "XI HAS DEAD " + std::to_string(score);
    SDL_Color color = {255, 255, 255, 255};
    SDL_Surface* surface = TTF_RenderUTF8_Solid(scorefont, scoreText.c_str(), color);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(game.getRenderer(), surface);
    SDL_Rect dst = {game.getWindowWidth() - 300,  10, surface->w, surface->h};
    SDL_RenderCopy(game.getRenderer(), texture, NULL, &dst);
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}
void Scenemain::shootplayer()
{
   auto projectile = new  projectileplayer(ProjectileplayerTemplate);
    // 定位在飞机顶部中央
    projectile->position.x = Player.position.x + Player.width / 2 - projectile->width / 2;
    projectile->position.y = Player.position.y;
    // 添加到活动子弹列表
    projectilesPlayer.push_back(projectile);
    Mix_PlayChannel(0, soundEffects["player_shoot"], 0); // 播放射击音效
    }



void Scenemain::updateplayerprojectiles(float deltaTime)
{
      int margin = 32; // 子弹超出屏幕外边界的距离
    for (auto it = projectilesPlayer.begin(); it != projectilesPlayer.end();){
        auto projectile = *it;
        // 更新子弹位置
        projectile->position.y -= projectile->speed * deltaTime;
        // 检查子弹是否超出屏幕
        if (projectile->position.y + margin < 0){
            delete projectile;
            it = projectilesPlayer.erase(it);
        }else {
            bool hit = false; // 标记子弹是否击中敌机
            for(auto enemy : enemies)
            {
                SDL_Rect projectileRect = {
                    static_cast<int>(projectile->position.x),
                    static_cast<int>(projectile->position.y),
                    projectile->width,
                    projectile->height
                };
                SDL_Rect enemyRect = {
                    static_cast<int>(enemy->position.x),
                    static_cast<int>(enemy->position.y),
                    enemy->width,
                    enemy->height
                };
                if (SDL_HasIntersection(&projectileRect, &enemyRect)) {
                    // 碰撞检测成功，处理碰撞
                    enemy->health -= projectile->damage;
                    delete projectile;
                    it = projectilesPlayer.erase(it);{
                    hit = true;
                    Mix_PlayChannel(-1, soundEffects["hit"], 0); // 播放命中音效
                    break;
                    }
                   
                }
            }
            if(!hit){
            ++it;} // 如果没有击中敌机，继续迭代
        }
    }
}

