#include "Game.h"
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include "SDL_mixer.h"
#include<iostream>

int main(int argc, char* argv[]){
    game& Game= game::getInstance();
    Game.init();
    Game.run();
    return 0;
}