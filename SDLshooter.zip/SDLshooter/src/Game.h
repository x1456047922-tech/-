#pragma once
#include "Scene.h"
#include "SDL.h"
#include "object.h"
#include <SDL_image.h>
#include<SDL_Mixer.h>
#include <SDL_ttf.h>
#include "SDL.h"
#include <string>
class game{
public:
    static game& getInstance(){
        static game instance;
        return instance;
    }
    ~game();
    void init();
    void run();
    void changeScene(scene* scene);
    void clean();
    void handleEvents(SDL_Event* event);
    void update(float deltaTime);
    void render();
    

    void rendertextcenter(std::string text, float posy,  bool istitle );
// 获取渲染器的成员函数
// 这是一个const成员函数，不会修改类的成员变量
// 返回SDL_Renderer指针，用于SDL2的渲染操作
    SDL_Renderer* getRenderer() const { return renderer; }
    SDL_Window* getWindow() const { return window; }
    int getWindowWidth() const { return windowWidth; }
    int getWindowHeight() const { return windowHeight; }
private:
    bool isRunning=true; 
    scene* currentScene= nullptr;
    SDL_Window* window= nullptr;
    game();
    game(const game&) = delete;
    game& operator=(const game&) = delete;
    SDL_Renderer* renderer= nullptr;
    int windowWidth=800;
    int windowHeight=600;
    int FPS=60;
    Uint32 frameTime;
    float deltaTime;
    background nearstars ;
    background farstars ;
    TTF_Font *title;
    TTF_Font *textfont;
    void backgroundupadte(float deltaTime);
    void backgroundrender();
};