#include "Scene.h"
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
class SceneTitle : public scene{

public:

 

   void update(float deltaTime) override;
   void render() override;
   void handleEvents(SDL_Event *event) override;
   void init() override;
   void clean() override;
private:
    Mix_Music *bgm;
    float timer = 0.0f; // 计时器
};